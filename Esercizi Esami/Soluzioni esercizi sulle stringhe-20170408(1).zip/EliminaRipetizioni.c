#include <stdio.h>
#include <string.h>

/* Funzione che riceve come parametro una stringa e 
 * la modifica eliminando tutte le ripetizioni consecutive 
 * di caratteri. Ad esempio se la stringa ricevuta come 
 * parametro � "aaabbcdddaa", la stringa verr� 
 * modificata in "abcda". */
void eliminaRipetizioni(char *stringa) {
	int i, j;			// contatori
	i = 0;			// ultimo carattere pulito	
	
	/* vai avanti fino alla fine della stringa */
	while(stringa[i] != '\0') {
		
		/* ripetizione da eliminare? */
		if(stringa[i]==stringa[i+1]) {
			/* copia tutti i caratteri da i+2 una posizione indietro */ 
			j=i+1;
			while(stringa[j] != '\0') {
				stringa[j] = stringa[j+1];
				j++;
			} 
		}
		else // niente ripetizione, vai avanti
			i++;
	}
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa, "); 
	printf(" ne elimina le ripetizioni e stampa la stringa ripulita.\n"); 
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* elimina ripetizioni */
	eliminaRipetizioni(stringa);
	
	/* output */
	printf("Ecco la stringa ripulita: %s", stringa);
}