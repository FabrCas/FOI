#include <stdio.h>
#include <string.h>

/* Funzione che riceve come parametro una stringa e riordina i 
 * caratteri della stringa cos� che tutti i caratteri alfabetici maiuscoli 
 * compaiono prima di tutti i caratteri alfabetici minuscoli. */
void maiuscoleMinuscole(char *stringa) {
	int i = 0;							// scorri da sinistra
	int j = strlen(stringa)-1;		// scorri da destra
	
	/* vai avanti fino a che gli indici non si incontrano */
	while(i<j) {
		
		/* il carattere con indice i sta bene dove sta? */
		if(!(stringa[i]>='a' && stringa[i]<='z'))
			i++;
		else {
			/* il carattere con indice j sta bene dove sta? */
			if(!(stringa[j]>='A' && stringa[j]<='Z')) 
				j--;
			else {
			/* il carattere con indice i � minuscolo e quello con indice
			 * j � maiuscolo: scambiali */
				char temp = stringa[i];
				stringa[i] = stringa[j];
				stringa[j] = temp;
			}
		}
	}
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa "); 
	printf("e riordina i caratteri cos� che i caratteri alfabetici maiuscoli ");
	printf("compaiono prima dei caratteri alfabetici minuscoli.\n"); 
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* elimina ripetizioni */
	maiuscoleMinuscole(stringa);
	
	/* output */
	printf("Ecco la stringa modificata: %s", stringa);
}