#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/* Funzione che riceve come parametro una stringa e ne fa uno shift, 
 * ovvero sposta di una posizione (verso destra) ciascun carattere 
 * della stringa. L'ultimo carattere diventa il primo dopo lo shift. */
void shift(char *stringa) {
	/* salva l'ultimo carattere */
	char temp = stringa[strlen(stringa)-1]; 
	/* sposta verso destra gli altri caratteri */
	for(int i=strlen(stringa)-2; i>=0; i--)
		stringa[i+1]=stringa[i];
	/* copia il primo carattere */
	stringa[0] = temp;
}


/* Funzione che riceve come parametro una stringa ed un intero x 
 * e modifica la stringa effettuando x operazioni di shift. */
void shiftParametrico(char *stringa, int x) {
	/* fai x shift */
	for(int i=0; i<x; i++)
		shift(stringa);
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa "); 
	printf("e ne stampa una versione shiftata di un numero ");
	printf("di posizioni casuale.\n"); 
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* genera un numero casuale */
	srand(time(NULL));
	int numeroShift = 1+(rand() % strlen(stringa));
	shiftParametrico(stringa, numeroShift);
	
	/* output */
	printf("Ecco la stringa shiftata di %d posizioni: %s", 
	numeroShift, stringa);
}