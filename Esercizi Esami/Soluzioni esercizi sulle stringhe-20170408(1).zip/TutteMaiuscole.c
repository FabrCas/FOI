#include <stdio.h>
#include <string.h>

/* Funzione che riceve come parametro una stringa e la modifica 
 * rendendo maiuscoli tutti i caratteri alfabetici minuscoli.  */
void tutteMaiuscole(char *stringa) {
	int i = 0;		// contatore caratteri della stringa
	
	/* vai avanti fino alla fine della stringa */
	while(stringa[i] != '\0') {
		/* alfabetico minuscolo? */
		if(stringa[i]>='a' && stringa[i]<='z')
			/* la differenza fra stringa[i] ed il corrispondente maiuscolo
			 * � pari alla differenza fra 'A' e 'a' */ 
			stringa[i] += 'A' - 'a'; 
		i++;		// vai al prossimo carattere
	}
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa, "); 
	printf("rende maiuscoli tutti i caratteri alfabetici minuscoli e ");
	printf(" stampa la stringa modificata.\n"); 
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* trasforma le minuscole in maiuscole */
	tutteMaiuscole(stringa);
	
	/* output */
	printf("Ecco la stringa modificata: %s", stringa);
}