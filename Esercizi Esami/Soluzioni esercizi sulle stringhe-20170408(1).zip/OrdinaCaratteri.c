#include <stdio.h>
#include <string.h>

/* funzione che scambia le posizioni di due elementi in una stringa */
void scambia(char *stringa, int i, int j) {
	char temp = stringa[i];
	stringa[i] = stringa[j];
	stringa[j] = temp;		
}

/* Funzione che riceve come parametro una stringa e riordina 
 * i caratteri della stringa in ordine crescente di codice 
 * associato al carattere. */
void ordinaCaratteri(char *stringa) {
	/* utilizziamo selection sort */
	char minimo;					// carattere a codice minimo
	int indice;	  					// indice del carattere a codice minimo
	int n = strlen(stringa);	// lunghezza della stringa

	/* per tutti gli indici fino al penultimo */
	for(int i=0; i<= n-2; i++) {
		/* trova il carattere minimo fra quelli con indice 
		 * compreso fra i e n-1 */
		indice = i;
		minimo = stringa[i];
		for(int j=i+1; j<= n-1; j++) {
			if(stringa[j]< minimo) {
				minimo = stringa[j];
				indice = j;
			}
		}
		/* hai trovato il carattere minimo, mettilo nella sua posizione definitiva */ 
		scambia(stringa,i,indice);
	}
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa "); 
	printf("e riordina i caratteri secondo il loro codice ASCII.\n"); 
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* elimina ripetizioni */
	ordinaCaratteri(stringa);
	
	/* output */
	printf("Ecco la stringa ordinata: %s", stringa);
}