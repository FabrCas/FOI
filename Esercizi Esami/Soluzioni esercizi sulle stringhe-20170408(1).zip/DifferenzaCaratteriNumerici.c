#include <stdio.h>
#include <string.h>

/* Funzione che riceve come parametro una stringa. La funzione 
 * restituisce la massima differenza fra due caratteri numerici che 
 * appartengono alla stringa e fra i quali non ci sono altri caratteri 
 * numerici, oppure -1 se la stringa non contiene due caratteri numerici. */
int differenzaCaratteriNumerici(char *stringa) {
	int i;								// per scandire la stringa
	int ultimoNumero;				// ultimo numero letto
	int numeroCorrente;			// numero corrente
	int differenzaAttuale;			// la differenza attuale 
	int differenzaMassima;		// la differenza massima 
	
	/* inizializzazioni */
	differenzaMassima = -1;
	ultimoNumero = -1;
	i = 0;			// prima posizione da guardare
	/* vai avanti fino alla fine della stringa */
	while(stringa[i] != '\0') {
		/* il carattere attuale � numerico? altrimenti non devi fare niente */
		if(stringa[i]>='0' && stringa[i]<='9') {
			/* prendi il numero corrente */
			numeroCorrente = stringa[i]-'0';
				
			/* hai gi� trovato caratteri numerici? */
			if(ultimoNumero!=-1) {
				
				/* calcola la differenza fra i due numeri */
				if(numeroCorrente>ultimoNumero)
					differenzaAttuale = numeroCorrente - ultimoNumero;
				else
					differenzaAttuale = ultimoNumero -  numeroCorrente;
				
				/* nuovo massimo? */
				if(differenzaAttuale>differenzaMassima)
					differenzaMassima = differenzaAttuale;
			}
	
			/* aggiorna l'ultimo numero */
			ultimoNumero = numeroCorrente;
		}
		i++;		// passa al prossimo carattere
	}
	return differenzaMassima;
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa "); 
	printf("e determina la massima differenza fra due caratteri"); 
	printf(" numerici nella stringa fra i quali non compaiono"); 
	printf(" altri caratteri numerici.\n"); 
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* invoca la funzione differenzaCaratteriNumerici */
	int differenza = differenzaCaratteriNumerici(stringa);
	
	/* output */
	if(differenza==-1)
		printf("La stringa non contiene due caratteri numerici");
	else
		printf("La massima differenza fra due caratteri numerici %c %d", 138, differenza);
}