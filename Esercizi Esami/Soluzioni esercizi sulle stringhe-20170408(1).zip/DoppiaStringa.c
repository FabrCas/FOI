#include <stdio.h>
#include <string.h>

/* Funzione che riceve come parametro una stringa e verifica se 
 * la stringa � costituita da due sottostringhe uguali. */
int doppiaStringa(char *stringa) {
	int ris = 1;						// valore da restituire		
	int n = strlen(stringa);	// lunghezza stringa
	int i = 0;						// contatore
	
	/* se lunghezza � dispari sicuramente no */
	if(n%2 != 0)
		ris = 0;
	
	else {
		/* confronta la posizione i con la posizione n/2 + i */
		while(ris && i<n/2)
			if(stringa[i]!=stringa[n/2 +i])
				ris = 0;
			else
				i++;
	}
	return ris;
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa e "); 
	printf("verifica se la stringa � costituita da due sottostringhe ");
	printf("uguali.\n");
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* verifica la propriet� */
	if(doppiaStringa(stringa))
		printf("E' costituita da due sottostringhe uguali!");
	else
		printf("Non %c costituita da due sottostringhe uguali!", 138);
}