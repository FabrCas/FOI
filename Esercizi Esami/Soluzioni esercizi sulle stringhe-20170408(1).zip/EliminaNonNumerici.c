#include <stdio.h>
#include <string.h>

/* Funzione che riceve come parametro una stringa e la 
 * modifica eliminando tutti i caratteri non numerici */
void eliminaNonNumerici(char *stringa) {
	int i, j;			// contatori
	i = 0;			// ultimo carattere considerato	
	
	/* vai avanti fino alla fine della stringa */
	while(stringa[i] != '\0') {
		
		/* carattere da eliminare? */
		if(!(stringa[i]>='0' && stringa[i]<='9')) {
			/* copia tutti i caratteri da i+1 una posizione indietro */ 
			j=i;
			while(stringa[j] != '\0') {
				stringa[j] = stringa[j+1];
				j++;
			} 
		}
		else // � un carattere numerico, vai avanti
			i++;
	}
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa, "); 
	printf(" ne elimina i caratteri non numerici e stampa la stringa risultante.\n"); 
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* elimina ripetizioni */
	eliminaNonNumerici(stringa);
	
	/* output */
	printf("Ecco la stringa numerica: %s", stringa);
}