#include <stdio.h>
#include <string.h>

/* Funzione che riceve come parametro una stringa. La funzione 
 * stampa un messaggio che indica quale carattere ha il maggior 
 * numero di occorrenze consecutive nella stringa e quante sono 
 * tali occorrenze. */
void numeroOccorrenze(char *stringa) {
	int i;								// per scandire la stringa
	char carattereAttuale;		// carattere sotto esame
	int occorrenzeAttuali;		// numero di occorrenze attuali
	char carattereMassimo;	// carattere a massimo numero occorrenze
	int occorrenzeMassime;	// massimo numero di occorrenze
	
	/* inizializzazioni */
	carattereAttuale = stringa[0];
	carattereMassimo = stringa[0];
	occorrenzeAttuali = 1;
	occorrenzeMassime = 1;
	i = 1;			// prima posizione da guardare
	/* vai avanti fino alla fine della stringa */
	while(stringa[i] != '\0') {
		/* stai continuando una sequenza? */
		if(stringa[i]==carattereAttuale) {
			/* aumenta le occorrenze attuali ed eventualmente 
			 * anche i dati sul massimo */
			occorrenzeAttuali++;
			if(occorrenzeAttuali>occorrenzeMassime) {
				carattereMassimo = carattereAttuale;
				occorrenzeMassime = occorrenzeAttuali;
			}
		}
		else { // nuovo carattere
			carattereAttuale = stringa[i];
			occorrenzeAttuali = 1;
		}
		i++;		// passa al prossimo carattere
	}

	/* output */
	printf("Il carattere con il maggior numero di occorrenze consecutive");
	printf(" %c %c che ha %d occorrenze consecutive", 138, 
	carattereMassimo, occorrenzeMassime);
}

/* funzione principale */
int main(){
	/* input */
	printf("Ciao, sono un programma che legge una stringa "); 
	printf("e determina il carattere che ha il massimo numero di ");
	printf("occorrenze consecutive e quante sono tali occorrenze.\n"); 
	char stringa[50];
	printf("Introduci una bella stringa: ");
	fgets(stringa, 50, stdin);
	
	/* rimuovi \n */
	stringa[strlen(stringa)-1]='\0';
	
	/* invoca la funzione numeroOccorrenze */
	numeroOccorrenze(stringa);
}