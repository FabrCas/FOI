#include <stdio.h>

/* funzione per la ricerca sequenziale all'interno di un 
 * array ordinato */
int ricercaSequenziale(int *a, int n, int k) {

	int trovato = 0;		// variabile di esistenza
	int i = 0;					// variabile contatore 
	while(i<n && !trovato) {
		if(a[i]==k)
			trovato = 1;
		else 
			i++;
	}
	return trovato;
}
 
int main(int argc, char **argv)
{
	int a[] = {1,2,5,6,6,9};
	printf("%d", ricercaSequenziale(a, 6, 5));
}
