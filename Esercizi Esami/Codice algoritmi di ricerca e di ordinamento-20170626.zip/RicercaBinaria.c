#include <stdio.h>

/* funzione per la ricerca binaria all'interno di un 
 * array ordinato */
int ricercaBinaria(int *a, int sin, int des, int k) {
	int appartiene;		// risultato
	/* CASO BASE */
	if(sin>des)
		appartiene = 0;
	/* PASSO RICORSIVO */
	else
		/* elemento centrale uguale a k? */
		if(a[(sin+des+1)/2]==k)
			appartiene = 1;
		else
			/* ricorri sequenza a sinistra */
			if(a[(sin+des+1)/2]>k)
				appartiene = ricercaBinaria(a, sin, (sin+des-1)/2, k);
			/* ricorri sequenza a destra */
			else
				appartiene = ricercaBinaria(a, (sin+des+3)/2, des, k);		
	return appartiene;
}
 
/* funzione per la ricerca binaria all'interno di un 
 * array ordinato */
int ricercaBinaria2(int *a, int n, int k) {
	int appartiene;		// risultato
	/* CASO BASE */
	if(n==0)
		appartiene = 0;
	/* PASSO RICORSIVO */
	else
		/* elemento centrale uguale a k? */
		if(a[n/2]==k)
			appartiene = 1;
		else
			/* ricorri sequenza a sinistra, che � lunga n/2 */
			if(a[n/2]>k)
				appartiene = ricercaBinaria2(a, n/2, k);
			/* ricorri sequenza a destra, che � lunga (n-1)/2 */
			else
				appartiene = ricercaBinaria2(a+n/2+1, (n-1)/2, k);		
	return appartiene;
}
 
int main(int argc, char **argv)
{
	int a[] = {-3,-1,-1,2,4,6,6,9,10,10,15};
	printf("%d", ricercaBinaria(a, 0,10, 3));
}
