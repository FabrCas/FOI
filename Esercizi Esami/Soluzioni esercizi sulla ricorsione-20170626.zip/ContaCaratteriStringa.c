#include <string.h>
#include <stdio.h>

/* funzione che conta quante volte il carattere parametro compare nella 
 * stringa parametro a partire dall'indice parametro */
int contaDaIndice(char *s, char c, int indice){
    int cont;		// il valore da restituire
	
	if (indice == strlen(s))
		/* l'indice � fuori dalla stringa */
		cont = 0;		
	else 
		/* confronta il primo carattere e ricorri sul resto della stringa */
		cont = (s[indice]==c) + contaDaIndice(s, c, indice+1);

	return cont;
}    
    
/* funzione che conta quante volte il carattere parametro compare nella 
 * stringa parametro */
int contaOccorrenze(char *s, char c) {
	 return contaDaIndice(s,c,0);
}

void testContaOccorrenze(){
    /* stringa vuota */
    printf("contaOccorrenze(\"\",'a') [0] = %d\n", contaOccorrenze("", 'a'));
    /* il primo carattere � quello cercato */
    printf("contaOccorrenze(\"aeiou\",'a') [1] = %d\n", contaOccorrenze("aeiou", 'a'));
    /* l'ultimo  carattere � quello cercato */
    printf("contaOccorrenze(\"aeiou\",'u') [1] = %d\n", contaOccorrenze("aeiou", 'u'));
    /* stringa con due caratteri uguali */
    printf("contaOccorrenze(\"casa\",'a') [2] = %d\n", contaOccorrenze("casa", 'a'));
    /* stringa senza occorrenze */
    printf("contaOccorrenze(\"casa\",'x') [0] = %d\n", contaOccorrenze("casa", 'x'));
    /* stringa con pi� caratteri uguali */
    printf("contaOccorrenze(\"supercalifragilistichespiralidoso\",'i') [6] = %d\n",contaOccorrenze("supercalifragilistichespiralidoso", 'i'));
}

int main() {
	testContaOccorrenze();
}