#include <stdio.h>
/* SPECIFICA DELLA FUNZIONE ARRAY2NUMERO
   INPUT: array a di interi
   PRE: a non nullo e non vuoto, gli elementi di a sono interi ad una cifra
   OUTPUT: un intero positivo o nullo num
   POST: num rappresenta il numero le cui cifre sono gli elementi dell'array
   Esempio: {1,2,3} ->  123 */

/* funzione che trasforma un array i cui elementi sono interi compresi fra 0 e 9 in un
 * numero le cui cifre sono gli elementi dell'array */
int trasforma(int a[], int lungh){
	int numero; 		// valore da restituire 

	if (lungh==1)
		/* un solo elemento */
		numero = a[lungh-1];
	else 
		/* pi� elementi */
		numero = trasforma(a,lungh-1)*10+a[lungh-1];

	return numero;
}

/* funzione per la stampa di un array */    
void stampaArray(int a[], int dim){
	int i;
	printf("Array:");
	for(i=0; i<dim; i++)
		printf(" %d ",a[i]);
	printf("\n");
}

/* funzione di test */    
void testTrasformaArray2Numero(){

	printf("******** TEST ARRAY 2 NUMERO ********\n");
	/* una sola cifra */
	int a1[1] = {8};
	stampaArray(a1,1);
	printf("numero corrispondente: %d \n",trasforma(a1,1)); 
	/* tre cifre */
	int a2[3] = {1,2,3};                                    
	stampaArray(a2,3);
	printf("numero corrispondente: %d \n",trasforma(a2,3));
}

/* funzione principale */
int main(){
    testTrasformaArray2Numero();
}