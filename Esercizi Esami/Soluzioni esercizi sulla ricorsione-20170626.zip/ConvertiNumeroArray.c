#include <stdio.h>
#include <stdio.h>

/* SPECIFICA DELLA FUNZIONE NUMERO2ARRAY
   INPUT: intero k
   PRE: k>=0
   OUTPUT: un array di interi a 
   POST: a � l'array delle cifre dell'intero k, dove a[0] contiene la cifra pi� significativa di k
   Es.: se k=2345 allora a = {2,3,4,5} */


/* funzione che dato un intero calcola il numero delle sue cifre */
int ncifre(int numero){
    int cont;		// il risultato
	
    if (numero/10==0)  
		/* caso base, una sola cifra */
		cont=1;
    else 
		/* passo induttivo, pi� di una cifra */
		cont = 1 + ncifre(numero/10);   
    return cont;
}

/* funzione per la stampa di un array */    
void stampaArray(int a[], int dim){
	int i;
	printf("Array:");
	for(i=0; i<dim; i++)
		printf(" %d ",a[i]);
	printf("\n");
}

/* funzione che memorizza dentro all'array v le cifre del numero n a partire da quella con indice i */
void arrayDaNumero(int v[], int n, int i){
	if (i==0)
		/* il numero ha una sola cifra */
		v[i] = n;
	else{
		/* pi� cifre, passo induttivo, inserisco l'ultima e ricorro */
		v[i] = n%10;
		arrayDaNumero(v,n/10,i-1);  // il numero  senza l'ultima cifra e i-1
	}
}     

/* funzione che dato un numero crea e stampa l'array i cui elementi sono le 
 * cifre del numero */
void numero2array(int n){
	int lungh;		// lunghezza array
	
	/* calcolo il numero di cifre di n e creo l'array della corrispondente dimensione */
	lungh=ncifre(n);
	int vett[lungh];
	
	/* invoco la funzione ricorsiva che memorizza nell'array v le cifre di n */
	arrayDaNumero(vett,n,lungh-1);
	
	/* stampo l'array */
	stampaArray(vett,lungh);
}
  
/* funzione di test */  
void testNumero2Array(){	
	
	printf("******** TEST ARRAY 2 NUMERO ********\n");
	
	/* una sola cifra */
	printf("1 = "); 
	numero2array(1); 
	
	/* quattro cifre */
	printf("3456 = "); 
	numero2array(3456); 
}


/* funzione principale */
int main() {
	testNumero2Array();
}

