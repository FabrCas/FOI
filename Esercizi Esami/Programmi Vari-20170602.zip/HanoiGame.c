#include <stdio.h>
#include <stdlib.h>

/***********************************************************/
/********* programma per giocare al gioco delle torri di Hanoi ********/
/***********************************************************/

/***********************************************************/
/********************** strutture *****************************/
/***********************************************************/

/* STRUTTURA PER GESTIRE I DISCHI */
struct Disco {
	int diametro;
	struct Disco* discoSotto;			// puntatore al disco sotto
} ;

/* UNA PILA E' UN PUNTATORE AL DISCO AFFIORANTE */
typedef struct Disco* Stack;

/***********************************************************/
/********************** funzioni ausiliarie **********************/
/***********************************************************/

/* massimo fra tre numeri */
int max(int a, int b, int c) {
	int massimo;		// da restituire
	if(a>=b && a>= c)
		massimo = a;
	else
		if(b>=c)
			massimo = b;
		else
			massimo = c;
	return massimo;
}

/* FUNZIONE PER IL CALCOLO DEL NUMERO DI DISCHI */
int numeroDischi(Stack s) {
	int numero = 0;		// da restituire
	Stack discoC = s;
	/* fino a che non sei su null sei su un disco */
	while(discoC!=NULL) {
		numero++;
		discoC = discoC -> discoSotto;
	}
	return numero;
}

/* VERIFICA STACK VUOTO */
int isNull(Stack s) {
	return s==NULL;
}

/* VERIFICA MOSSA LECITA */
int siPuo(Stack da, Stack a) {
	// pre: da non null
	/* la mossa la puoi fare se: il disco destinazione � vuoto o il disco affiorante sullo stack da
	 * ha diametro minore del disco affiorante sullo stack a */
	int yes;		// da restituire
	if(a== NULL)
		yes = 1;
	else 
		yes= da->diametro < a->diametro;
	return yes;
}
/***********************************************************/
/************************* creazione *************************/
/***********************************************************/

/* FUNZIONE RICORSIVA PER CREARE UNA PILA ORDINATA IN CUI I DISCHI SONO n ED 
 * IL PIU' PICCOLO HA DIAMETRO PARI A x */
Stack creaPilaRic(int n, int x) {
	Stack s = NULL;		// primo disco: indirizzo da restituire
	/* nel caso base (n==0) non devi fare niente */
	if(n>0) {
		/* alloca memoria per il disco pi� piccolo */
		s = malloc(sizeof(struct Disco));
		/* il diametro � x e il resto della pila � costruita ricorsivamente */
		s->diametro = x;
		s->discoSotto = creaPilaRic(n-1,x+2);
	}
	return s;
}

/* FUNZIONE PER CREARE UNA PILA ORDINATA */
Stack creaPila(int n) {
	return creaPilaRic(n,2);
}

/***********************************************************/
/*********************** visualizzazione ***********************/
/***********************************************************/

/* FUNZIONE PER VISUALIZZARE UNO STATO DEL GIOCO */
void visualizza(Stack s1, Stack s2, Stack s3) {
	int i, j;			// contatori
	Stack disco1 = s1;
	Stack disco2 = s2;
	Stack disco3 = s3;
	
	/* lunghezze */
	int numero1 = numeroDischi(s1);
	int numero2 = numeroDischi(s2);
	int numero3 = numeroDischi(s3);
	
	int numeroRighe = max(numero1,numero2,numero3);
	int basePila = 2*(numero1+numero2+numero3);
	
	/* stampa una riga alla volta: sono numeroRighe righe da stampare */
	printf("\n\n");
	for(i=1; i<=numeroRighe; i++) {

		/***************************************************/
		/****************** prima pila ***********************/
		/***************************************************/
		/* la prima pila inizia alla riga numeroRighe-numero1+1: quando i vale quel valore devi
		 * iniziare a stampare asterischi */
		if(i>=numeroRighe-numero1+1) {	// � iniziata
			/* il diametro del disco attuale � disco1->diametro: il numero di spazi bianchi iniziali
				� 1 + la basePila/2 - il diametro/2*/
			for(j=0;j<basePila/2 -(disco1->diametro)/2+1; j++) printf(" ");
			/* adesso stampa gli asterischi */
			for(j=0;j<disco1->diametro;j++) printf("*");
			/* gli spazi bianchi finali sono come quelli iniziali */
			for(j=0;j<basePila/2 -(disco1->diametro)/2+1; j++) printf(" ");
			
			/* passa al prossimo disco della prima pila */
			disco1 = disco1->discoSotto;
		}
		else // non � iniziata
			for(j=0;j<basePila+2;j++) printf(" ");

		/***************************************************/
		/****************** seconda pila ***********************/
		/***************************************************/
		/* la seconda pila inizia alla riga numeroRighe-numero2+1: quando i vale quel valore devi
		 * iniziare a stampare asterischi */
		if(i>=numeroRighe-numero2+1) {	// � iniziata
			/* il diametro del disco attuale � disco2->diametro: il numero di spazi bianchi iniziali
				� 1 + la basePila/2 - il diametro/2*/
			for(j=0;j<basePila/2 -(disco2->diametro)/2+1; j++) printf(" ");
			/* adesso stampa gli asterischi */
			for(j=0;j<disco2->diametro;j++) printf("*");
			/* gli spazi bianchi finali sono come quelli iniziali */
			for(j=0;j<basePila/2 -(disco2->diametro)/2+1; j++) printf(" ");
			
			/* passa al prossimo disco della prima pila */
			disco2 = disco2->discoSotto;
		}
		else // non � iniziata
			for(j=0;j<basePila+2;j++) printf(" ");

		/***************************************************/
		/****************** terza pila ***********************/
		/***************************************************/
		/* la terza pila inizia alla riga numeroRighe-numero3+1: quando i vale quel valore devi
		 * iniziare a stampare asterischi */
		if(i>=numeroRighe-numero3+1) {	// � iniziata
			/* il diametro del disco attuale � disco3->diametro: il numero di spazi bianchi iniziali
				� 1 + la basePila/2 - il diametro/2*/
			for(j=0;j<basePila/2 -(disco3->diametro)/2+1; j++) printf(" ");
			/* adesso stampa gli asterischi */
			for(j=0;j<disco3->diametro;j++) printf("*");
			/* gli spazi bianchi finali sono come quelli iniziali */
			for(j=0;j<basePila/2 -(disco3->diametro)/2+1; j++) printf(" ");
			
			/* passa al prossimo disco della prima pila */
			disco3 = disco3->discoSotto;
		}
		else // non � iniziata
			for(j=0;j<basePila+2;j++) printf(" ");

		printf("\n");
	}	
	printf("\n");
}

/******************************************************
 ********************* inserimento *********************
 ******************************************************/ 

/* funzione che inserisce un elemento in testa alla pila */		
Stack push(Stack s, int x) {
	Stack disco = malloc(sizeof(struct Disco)); 		// nuovo  nodo 
	
	/* valore del campo dati */
	disco->diametro = x;
	
	/* collega il disco al successivo */
	disco->discoSotto = s;
	
	/* restituisci l'indirizzo del nuovo primo elemento */
	return disco;								
}

/******************************************************
 ********************* cancellazione *********************
 ******************************************************/ 

/* funzione che cancella un disco dalla testa della pila */		
Stack pop(Stack s) {
	// pre: la pila non � vuota
	 Stack disco;			// il nuovo primo disco della pila
	
	disco = s->discoSotto;
	/* viene deallocata la memoria del primo disco */
	free(s);
	
	return disco;
}

/******************************************************
 ********************* main *********************
 ******************************************************/ 
int main() {
	int dimensione;			// numero di dischi
	int da, a;					// che movimento vuole fare l'utente?	
	Stack sDa, sA;			// stacks di supporto
	
	/* inizializza il gioco */
	printf("Caro utente, benvenuto al gioco della torre di Hanoi!\n");
	printf("Con che dimensione vuoi giocare?\n");
	scanf("%d", &dimensione);
	Stack s1 = creaPila(dimensione);
	Stack s2 = creaPila(0);
	Stack s3 = creaPila(0);

	printf("Configurazione iniziale:");
	visualizza(s1,s2,s3);
	
	/* vai avanti fino a che tutte i dischi non sono stati spostati nella seconda 
	 * o nella terza pila */
	while(numeroDischi(s1)!=0 || (numeroDischi(s2)!=0 &&numeroDischi(s3)!=0)) {
		/* chiedi una mossa all'utente */
		do{
			sDa = NULL;
			printf("Da quale stack vuoi spostare un disco? ");
			scanf("%d", &da);
			if(da==1) {
				if(!isNull(s1))
					sDa=s1;
				else
					printf("Non %c possibile: Lo stack %c vuoto!\n\n", 138, 138);
			}
			else 	if(da==2) {
				if(!isNull(s2))
					sDa=s2;
				else
					printf("Non %c possibile: Lo stack %c vuoto!\n\n", 138, 138);
			}
			else if(da==3) {
				if(!isNull(s3))
					sDa=s3;
				else
					printf("Non %c possibile: Lo stack %c vuoto!\n\n", 138, 138);
			} 
			else printf("Ci sono solo tre stacks!!\n\n");
		}
		while(sDa== NULL);
		
		do{
			sA = NULL;
			printf("\nVerso quale stack vuoi spostare il disco? ");
			scanf("%d", &a);
			if(a==1)
				sA=s1;
			else 	if(a==2)
				sA=s2;
			else 	if(a==3)
				sA=s3;
			else
				printf("Ci sono solo tre stacks!!\n");
		}
		while(a<1 || a>3);

		/* controlla se la mossa � lecita */
		if(!siPuo(sDa,sA))
			printf("\nMi dispiace, questa mossa non %c lecita!\n\n", 138);
		/* OK procediamo a fare la mossa */
		else {
				printf("\nOK! Eseguo!\n");
				/* il disco da spostare diventa il primo della lista sA */
				sA=push(sA, sDa->diametro);
				/* il disco va rimosso dalla pila sDa */
				sDa=pop(sDa);

				/* ripristina i puntatori giusti */
				if(da==1)
					s1=sDa;
				else 	if(da==2)
					s2=sDa;
				else 	if(da==3)
					s3=sDa;
				
				/* ripristina i puntatori giusti */
				if(a==1)
					s1=sA;
				else 	if(a==2)
					s2=sA;
				else 	if(a==3)
					s3=sA;
				
				printf("Nuova configurazione:");
				visualizza(s1,s2,s3);
		}
	} 
	
	/* FINITO! */
	printf("COMPLIMENTI!\n\n");
}
