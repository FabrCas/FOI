/* Realizzare un'applicazione per gestire una lista ordinata di rette nel piano. L'applicazione deve gestire
 * ciascuna retta come una struttura con i seguenti tre campi: (1) un valore booleano che indica se la 
 * retta � verticale oppure no; (2) un numero razionale che rappresenta il coefficiente angolare della 
 * retta; (3) un numero razionale che rappresenta l'intercetta della retta. Ciascun numero razionale 
 * deve essere gestito come una struttura con due campi, rappresentanti numeratore e denominatore. 
 * 
 * La lista deve essere ordinata per coefficiente angolare crescente, dove le rette verticali si assumono 
 * essere quelle con coefficiente angolare massimo. Nel caso in cui una retta sia verticale, 
 * il campo che rappresenta il coefficiente angolare non � rilevante, mentre il campo intercetta 
 * rappresenta l'ordinata dell'intersezione con l'asse delle x.
 * 
 * L'applicazione deve permettere all'utente di svolgere le seguenti funzionalit�.
 * 
 * - Inserimento di una nuova retta nella lista ordinata (mantenendo l'ordinamento).
 * - Cancellazione della retta in testa alla lista.
 * - Visualizzazione della lista corrente di rette.
 * 
 * All'avvio dell'esecuzione l'applicazione deve inizializzare la lista di rette con i valori letti da un file; 
 * al termine dell'esecuzione l'applicazione deve salvare i dati della lista nello stesso file.  */ 

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/* un numero razionale */
struct Numero{
    int num;
    int den;
};

/* una retta */
struct Retta {
    int verticale;
	struct Numero coefficiente;
	struct Numero intercetta;
};

/* per la lista di rette */
struct Nodo{
    struct Retta retta;
    struct Nodo* next;
};

/**********************************************
 ************ CREAZIONE LISTA VUOTA ************
 **********************************************/
struct Nodo* crea() {
	return NULL;
}

/**********************************************
 ******************** STAMPE ******************
 **********************************************/

/* per stampare una retta */
void stampaRetta(struct Retta retta) { 
	/* sappiamo che il denominatore di coefficiente e intercetta sono diversi da zero */  
	if(retta.verticale == 1) { // non c'� il termine con la y
		printf("L'equazione della retta %c x =", 138);
		if(retta.intercetta.num==0)	
			printf(" 0\n");
		else { 
			/* segno */
			if((retta.intercetta.num>0 && retta.intercetta.den<0) ||
			   (retta.intercetta.num<0 && retta.intercetta.den>0)) 
				   printf(" -");
			/* num e den positivi */
			if(retta.intercetta.num<0)
				retta.intercetta.num= -retta.intercetta.num;
			printf(" %d", retta.intercetta.num);
			if(retta.intercetta.den<0)
				retta.intercetta.den= -retta.intercetta.den;
			if(retta.intercetta.den!= 1)
				printf("/%d\n", retta.intercetta.den);
			else 
				printf("\n");
		}
	} // c'� il termine con la y
	else { 
		printf("L'equazione della retta %c y =", 138);
		/* stampa il termine mx se c'� */
		if(retta.coefficiente.num!=0) {	// il termine c'�
			/* segno */
			if((retta.coefficiente.num>0 && retta.coefficiente.den<0) ||
			   (retta.coefficiente.num<0 && retta.coefficiente.den>0)) 
				   printf(" -");
			/* num e den positivi */
			if(retta.coefficiente.num<0)
				retta.coefficiente.num= -retta.coefficiente.num;
			printf(" %d", retta.coefficiente.num);
			if(retta.coefficiente.den<0)
				retta.coefficiente.den= -retta.coefficiente.den;
			if(retta.coefficiente.den!= 1)
				printf("/%d", retta.coefficiente.den);
		}
		/* stampa il termine q se c'� */
		if(retta.intercetta.num==0)	
			if(retta.coefficiente.num==0)
				printf(" 0\n");
			else
				printf("\n");
		else { 
			/* segno */
			if((retta.intercetta.num>0 && retta.intercetta.den<0) ||
			   (retta.intercetta.num<0 && retta.intercetta.den>0)) 
				printf(" -");
			else  {
				if(retta.coefficiente.num!=0)
					printf(" +");
			}
			/* num e den positivi */
			if(retta.intercetta.num<0)
				retta.intercetta.num= -retta.intercetta.num;
			printf(" %d", retta.intercetta.num);
			if(retta.intercetta.den<0)
				retta.intercetta.den= -retta.intercetta.den;
			if(retta.intercetta.den!= 1)
				printf("/%d\n", retta.intercetta.den);
			else 
				printf("\n");
		}
	}
}

/* per stampare una lista di numeri razionali */
void stampa(struct Nodo* lista) {
	/* vai avanti fino a che ci sono numeri */
	if(lista==NULL)
		printf("La lista %c vuota\n\n", 138);
	else {
		printf("Ecco la lista di rette\n\n");
		while(lista!= NULL) {
			stampaRetta(lista->retta);
			lista = lista->next;
		}
		printf("\n");
	}
}

/**********************************************
 ************ INSERIMENTO ORDINATO ************
 **********************************************/

/* verifica se una retta precede un'altra */
int precede(struct Retta r1,struct Retta r2) {
	int vero;			// da restituire
	/* se la seconda � verticale, allora s� */
	if(r2.verticale==1)
		vero = 1;
	else
		/* se la prima � verticale, allora no */
		if(r1.verticale==1)
			vero = 0;
		/* puoi confrontare i coefficienti */
		else
			vero = ((float)r1.coefficiente.num)/((float)r1.coefficiente.den) <= 
			((float)r2.coefficiente.num)/((float)r2.coefficiente.den);
	return vero;
}

/* inserimento di una retta nella lista ordinata; implementa soluzione 
 * con doppio puntatore */
void inserisci(struct Nodo** lista, struct Retta r) {
	/* alloca memoria per il nodo */
	struct Nodo* nodo = malloc(sizeof(struct Nodo));
	/* riempi il campo dati */
	nodo->retta = r;
	
	/* cerca il posto giusto per l'inserimento */

	/* se la lista � vuota devi inserirlo subito*/
	if(*lista==NULL) {
		nodo->next = NULL;
		*lista = nodo;
	}
	/* altrimenti la lista non � vuota */ 
	else { 
		/* il nuovo elemento diventa il primo? */
		if(precede(r,(*lista)->retta)) {
			nodo->next = *lista;
			*lista = nodo;
		}
		/* il nuovo elemento non diventa il primo */
		else { 
			struct Nodo* nodoPrec = *lista;
			struct Nodo* nodoCurr = nodoPrec->next;
			/* adesso cicla fino a che nodoPrec e nodoCurr sono i due elementi fra i quali inserire nodo */
			int trovato = 0;
			while(nodoCurr!= NULL && !trovato) {
				if(precede(r,nodoCurr->retta)) {
					trovato = 1;
				}
				else {
					nodoPrec = nodoCurr;
					nodoCurr = nodoCurr->next;
				}
			}
			/* inserisci fra i nodi */
			nodoPrec->next = nodo;
			nodo->next = nodoCurr;		// pu� essere NULL
		}
	}
}

/* inserimento ordinato di una retta con lettura */
void nuovaRetta(struct Nodo** lista) {
	struct Retta r;		// da inserire
	printf("Caro utente, la retta %c verticale (1=SI, 0=NO)?  ", 138);
	scanf("%d", &r.verticale);
	if(r.verticale) {

		/* intercetta con x */
		printf("Caro utente, qual %c il numeratore dell'intercetta con l'asse delle x? ", 138);
		scanf("%d", &r.intercetta.num);
		do{
			printf("Caro utente, qual %c il denominatore dell'intercetta? ", 138);
			scanf("%d", &r.intercetta.den);
			if(r.intercetta.den==0)
				printf("Questo valore deve essere diverso da zero\n");
		}
		while(r.intercetta.den==0);
	}	
	else {
		/* coefficiente */
		printf("Caro utente, qual %c il numeratore del coefficiente angolare? ", 138);
		scanf("%d", &r.coefficiente.num);
		do{
		printf("Caro utente, qual %c il denominatore del coefficiente angolare? ", 138);
		scanf("%d", &r.coefficiente.den);
			if(r.coefficiente.den==0)
				printf("Questo valore deve essere diverso da zero\n");
		}
		while(r.coefficiente.den==0);
		
		/* intercetta */
		printf("Caro utente, qual %c il numeratore dell'intercetta? ", 138);
		scanf("%d", &r.intercetta.num);
		do{
			printf("Caro utente, qual %c il denominatore dell'intercetta? ", 138);
			scanf("%d", &r.intercetta.den);
			if(r.intercetta.den==0)
				printf("Questo valore deve essere diverso da zero\n");
		}
		while(r.intercetta.den==0);
	}
	inserisci(lista,r);
	printf("Inserito!\n\n");
}


/*********************************************
 ************** CANCELLAZIONE *****************
 *********************************************/

/* funzione che elimina un nodo dalla testa della lista */		
void eliminaRetta(struct Nodo** lista) {
	struct Nodo *nodo;											// il nuovo primo nodo della lista
	
	/* se la lista � vuota non fare niente */
	if(*lista!=NULL) {
		/* salva il nuovo primo nodo */
		nodo = (*lista)->next;
		/* dealloca la memoria del primo nodo */
		free(*lista);
		/* nuova testa della lista */
		*lista = nodo;
		printf("Cancellata!\n\n");
	}
	else 
		printf("La lista %c vuota!\n\n", 138);
}

/**********************************************
 **************** GESTIONE FILE ****************
 **********************************************/

/* funzione per l'acquisizione di una lista su file */
struct Nodo* acquisizione() {
	FILE* fp = fopen("rette.dat", "rb");					// per la lettura di un file binario
	struct Nodo* head;											// testa della lista
	struct Nodo* current;										// nodo corrente
	struct Nodo* previous;										// nodo precedente
	
	struct Retta r;													// una retta
	int letto;														// lettura OK o no
	
	/* leggi il primo nodo della lista */
	letto = fread(&r, sizeof(struct Retta), 1, fp);
	if(letto) {		// almeno una retta � presente nel file
		/* memorizza nell'heap il primo nodo della lista */ 
		head = malloc(sizeof(struct Nodo)) ;			
		head->retta = r;
		
		/* devi tenere traccia dell'ultimo nodo letto, per collegarlo al successivo nella lista */
		previous = head;				
		/* adesso leggi tutti gli altri nodi */
		do {		
			/* leggi un nuovo nodo */
			letto = fread(&r, sizeof(struct Retta), 1, fp);
			if(letto) {		// lo hai effettivamente letto?
				/* memorizza nell'heap il nuovo nodo */ 
				current = malloc(sizeof(struct Nodo)) ;			
				current->retta = r;
				
				/* collega il nuovo nodo al precedente */
				previous->next = current;
				
				/* il nuovo nodo diventa il precedente */
				previous = current;
			}
			else // il file � terminato, setta il campo next dell'ultimo nodo 
				previous -> next = NULL;
		}
		while(letto);
	}
	else // file vuoto
		head = NULL;
	return head;
}

/* funzione per il salvataggio di una lista su file */
void salvataggio(struct Nodo* lista) {
	FILE* fp = fopen("rette.dat", "wb");								// per la scrittura di un file binario
	while(lista!= NULL) {													// procedi fino a che hai nodi 
		fwrite(&(lista->retta), sizeof(struct Retta), 1, fp);		// ci� che scrivi � una retta
		lista = lista->next;													// passa al prossimo nodo
	} 
}

/**********************************************
 ************ FUNZIONE PRINCIPALE ************
 **********************************************/

int main() {
	/* crea la lista */
	struct Nodo* lista = acquisizione();
	
	int risposta = -1;			// per interazione con utente
	
	while(risposta != 0) {
		/* richiedi un'operazione all'utente */
		printf("Che operazione vuoi svolgere?\n");
		printf("1 -> Inserisci una retta nella lista ordinata\n");
		printf("2 -> Cancella la prima retta della lista\n");
		printf("3 -> Visualizza la lista\n");
		printf("0 -> Termina il programma\n");
		scanf("%d", &risposta);
		
		/* gestisci le operazioni dell'utente */
		if(risposta==1) {
			nuovaRetta(&lista);
		}
		else if(risposta==2) {
			eliminaRetta(&lista);
		}
		else if(risposta==3) {
			stampa(lista);
		}
		else if(risposta==0) {
			printf("Adios!\n\n");
		}
		else printf("Selezione non valida!\n\n");
	}
	salvataggio(lista);
}