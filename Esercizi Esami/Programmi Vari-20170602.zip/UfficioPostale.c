#include <stdio.h>

/* Programma per gestire un ufficio postale. L'ufficio ha due code, una per le operazioni
 * postali, una per le operazioni bancarie. Quando arriva una persona, viene inserita nella
 * giusta coda, assegnando a quella persona un codice composto da un carattere (B per le
 * operazioni bancarie, P per quelle postali) e memorizzando l'orario di arrivo. L'ufficio ha tre 
 * sportelli, uno dedicato alle operazioni postali, uno dedicato alle operazioni bancarie ed uno per 
 * entrambi i tipi di operazioni. Quando uno sportello termina di servire un cliente chiama
 * una nuova persona in fila allo sportello, selezionandola dalla giusta coda. In particolare
 * se lo sportello libero � quello che serve entrambe le operazioni, viene chiamata la persona
 * che � arrivata prima all'ufficio postale */
 
#include <stdio.h>
#include <stdlib.h>

/* orario */
struct Ora {
	int ore;
	int minuti;
};

/* per gestire le persone */
struct Persona {
	char numero[3];				// codice
	struct Ora arrivo;			// ora arrivo
	struct Persona *next;			// prossima persona in coda
} ;

/* puntatori alla testa e alla coda della lista */
struct Puntatori {
	struct Persona* head;
	struct Persona* tail;
};

/* uno queue � un puntatore ad una struttura puntatori */
typedef struct Puntatori* Queue;

/******************************************************
 ********************* CREAZIONE ***********************
 ******************************************************/ 

/* crea la struttura puntatori, che inizialmente non punta a niente */
Queue empty() {
	Queue q = malloc(sizeof(struct Puntatori));
	q->head = NULL;
	q->tail = NULL;
	return q;
}

/******************************************************
 ********************* TEST CODA VUOTA *****************
 ******************************************************/ 

/* verifica coda vuota */
int null(Queue q) {
	return q->head==NULL;
}

/*********************************************************
 ************************ LUNGHEZZA ***********************
 *********************************************************/ 
int lunghezzaCoda(Queue q) {
	int lunghezza=0;								// da restituire								
	struct Persona* p = q->head;				// per gestire le persone in coda
	while(p!= NULL) {
		lunghezza++;
		p = p -> next;
	}
	return lunghezza;
}

/*********************************************************
 ************************ STAMPA **************************
 *********************************************************/ 

void stampa(Queue q) {
	struct Persona* p = q->head;				// per gestire i nodi		
	while(p!= NULL) {
		printf("%c%c%c\n", p->numero[0],p->numero[1],p->numero[2]);
		p = p -> next;
	}
	printf("\n");
}

/******************************************************
 ******************** PRIMO ELEMENTO ******************
 ******************************************************/ 

/* funzione che restituisce un puntatore all'elemento in testa alla coda */		
struct Persona* front(Queue q) {
	// pre: almeno un elemento
	return q->head;
}

/******************************************************
 ********************* INSERIMENTO *********************
 ******************************************************/ 

/* l'inserimento avviene in coda */
Queue enqueue(Queue q, char c, int n) {
	struct Persona* p = malloc(sizeof(struct Persona)); 		// nuova  persona 
	
	/* identificativo persona: il primo carattere � B o P */
	p -> numero[0] = c; 
	/* il secondo e terzo carattere rappresentano il numero n: se � <10, allora il primo � 0 */
	if(n<10) {
		p -> numero[1] = '0';
		p -> numero[2] = '0'+n;
	}
	else {
		p -> numero[1] = '0' + (n/10);
		p -> numero[2] = '0' + (n%10);
	}
	
	/* l'ora di arrivo va letta */
	printf("Introduci l'ora: ");
	scanf("%d%*c", &(p->arrivo.ore));
	printf("Introduci i minuti: ");
	scanf("%d%*c", &(p->arrivo.minuti));
	
	/* il nodo � l'ultimo */
	p->next = NULL;
	
	/* collega il nodo al precedente, se esiste */
	if(!null(q)) 
		q->tail->next = p;
	/* se non esiste questo � il primo nodo */
	else 
		q->head = p;
	/* in ogni caso, il nuovo nodo diventa l'ultimo */
	q->tail = p;
		
	return q;			// questa restituzione non � necessaria, ma manteniamo il prototipo	
}

/******************************************************
 ********************* CANCELLAZIONE *******************
 ******************************************************/ 

/* funzione che cancella una persona dalla testa della coda */		
Queue dequeue(Queue q) {
	// pre: la coda non � vuota
	
	/* salva il nodo da cancellare */
	struct Persona* primo = q->head;
	/* ci sono altre persone? */
	if(q->head!=q->tail) 
		/* la persona successiva diventa la head */
		q->head = primo->next; 
	else {	// la coda diventa vuota
		q->head = NULL;
		q->tail = NULL;
	}
	/* dealloca il nodo */
	free(primo);
	return q;
}

/* servi cliente in coda */
void serviCliente(Queue q) {
	// pre: q non vuota
	struct Persona* p;					// puntatore ad una persona
	char operazione;						// quale operazione deve fare il cliente 
	
	/* annuncia al prossimo cliente che tocca a lui */
	p = front(q);
	printf("Puoi annunciare che tocca al cliente %c%c%c!\n",
	p->numero[0],p->numero[1],p->numero[2]);
	operazione = 	p->numero[0];
			
	/* togli dalla coda il primo cliente */
	dequeue(q);
	printf("Stampo la coda %c dopo la modifica!\n\n",operazione);
	stampa(q);
}		


/*********************************************************
 ************************ MAIN ****************************
 *********************************************************/ 

/* funzione principale */
int main() {
	int risposta = -1;					// valore inserito dall'impiegato
	char operazione;						// operazione bancaria o postale
	int sportello;							// sportello dell'ufficio
	int lungh;								// lunghezza coda
	
	Queue qB = empty();				// coda per operazioni bancarie
	Queue qP = empty();				// coda per operazioni postali
	
	int nB=0;								// numero progressivo per operazioni bancarie
	int nP=0;								// numero progressivo per operazioni postali
	
	/* ciclo di interazione con l'utente */
	while(risposta!=0) {
		printf("Che operazione vuoi svolgere?\n");
		printf("Introduci 1 -> Inserisci nuova persona\n");
		printf("Introduci 2 -> Chiama persona allo sportello\n");
		printf("Introduci 0 -> Termina il programma\n");
		scanf("%d%*c", &risposta);

		/* INSERIMENTO PERSONA */
		if(risposta==1) {
			printf("Che tipo di operazione vuole svolgere il cliente?\n");
			printf("Introduci B -> Operazione bancaria\n");
			printf("Introduci P -> Operazione postale\n");
			scanf("%c%*c", &operazione);
			if(operazione=='B'){
				lungh = lunghezzaCoda(qB);
				qB = enqueue(qB, operazione, nB);
				printf("Il cliente %c stato inserito in coda!\n",138);
				printf("Ha %d persone davanti!\n\n", lungh);
				printf("Stampo la coda B dopo l'arrivo!\n\n");
				stampa(qB);
				nB = (nB+1)%100;
			}
			else if(operazione=='P'){
				lungh = lunghezzaCoda(qP);
				qP = enqueue(qP, operazione, nP);
				printf("Il cliente %c stato inserito in coda!\n",138);
				printf("Ha %d persone davanti!\n\n", lungh);
				printf("Stampo la coda P dopo l'arrivo!\n\n");
				stampa(qP);
				nP = (nP+1)%100;
			}
			else printf("Le scelte possibili sono B o P!\n\n");
				
		}
		/* NUOVA PERSONA ALLO SPORTELLO */ 
		else if(risposta==2) {
			printf("Quale sportello si %c liberato?\n",138);
			printf("Introduci 1 -> Sportello bancario\n");
			printf("Introduci 2 -> Sportello postale\n");
			printf("Introduci 3 -> Sportello multifunzionale\n");
			scanf("%d%*c", &sportello);
			/* nel caso 1 e 2 la scelta � facile */
			if(sportello==1){
				/* togli dalla coda per operazioni bancarie il prossimo cliente, se c'� */
				if(null(qB)) {
					printf("La coda %c vuota!\n\n",138);
				}
				else {
					serviCliente(qB);
				}
			}
			else if(sportello==2){
				/* togli dalla coda per operazioni postali il prossimo cliente, se c'� */
				if(null(qP)) {
					printf("La coda %c vuota!\n\n",138);
				}
				else {
					serviCliente(qP);
				}
			}
			else if(sportello==3){
				/* per vedere quale coda devi gestire, devi confrontare gli orari di arrivo
				 * dei due clienti in testa alla coda, se ce ne sono */
				if(null(qP) && null(qB)) 
					printf("Non ci sono clienti in attesa!\n\n");
				else 
					if(null(qP))	// P vuota, gestisci B
						serviCliente(qB);
					else 
						if(null(qB))	// B vuota, gestisci P
							serviCliente(qP);
						else		// entrambe non vuote, gestisci quella che ha la persona arrivata prima
							if(qB->head->arrivo.ore<qP->head->arrivo.ore ||
							(qB->head->arrivo.ore==qP->head->arrivo.ore) &&
							(qB->head->arrivo.minuti<=qP->head->arrivo.minuti))
								serviCliente(qB);
							else
								serviCliente(qP);
			}
		}
		/* numero sbagliato? */
		else  if(risposta!=0)
			printf("Questo numero non vuol dire niente. Riproviamo!\n\n");
	}
}	