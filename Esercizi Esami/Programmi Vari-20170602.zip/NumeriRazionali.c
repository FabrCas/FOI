/* Realizzare un'applicazione per gestire numeri razionali. L'applicazione deve gestire ciascun numero 
 * razionale come una struttura con due campi, che rappresentano numeratore e denominatore 
 * del numero razionale. 
 * 
 * L'applicazione deve permettere all'utente di svolgere le seguenti funzionalit�.
 * - Inserimento di un nuovo numero razionale in testa alla lista.
 * - Cancellazione del numero razionale in fondo alla lista.
 * - Visualizzazione della lista corrente di numeri razionali. 
 * - Ordinamento della lista di numeri razionali in base al loro valore. 
 * - Riduzione di tutti i numeri razionali della lista ai minimi termini. 
 * 
 * All'avvio dell'esecuzione l'applicazione deve inizializzare la lista di numeri razionali con i valori 
 * letti da un file; al termine dell'esecuzione l'applicazione deve salvare i dati della lista nello stesso file. */ 

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/* un numero razionale */
struct Numero{
    int num;
    int den;
};

/* per la lista di numeri */
struct Nodo{
    struct Numero n;
    struct Nodo* next;
};

/**********************************************
 ************ CREAZIONE LISTA VUOTA ************
 **********************************************/
struct Nodo* crea() {
	return NULL;
}

/**********************************************
 ******************** STAMPE ******************
 **********************************************/

/* per stampare un numero */
void stampaNumero(struct Numero numero) {
	printf("Il numero razionale %c %d/%d\n", 138, numero.num, numero.den);
}

/* per stampare una lista di numeri razionali */
void stampa(struct Nodo* lista) {
	/* vai avanti fino a che ci sono numeri */
	if(lista==NULL)
		printf("La lista %c vuota\n\n", 138);
	else {
		printf("Ecco la lista di numeri\n\n");
		while(lista!= NULL) {
			stampaNumero(lista->n);
			lista = lista->next;
		}
		printf("\n");
	}
}

/**********************************************
 ************ INSERIMENTO IN TESTA ************
 **********************************************/

/* inserimento di un numero con dato num e den */
struct Nodo* inserisci(struct Nodo* lista, int x, int y) {
	/* alloca memoria per il nodo */
	struct Nodo* testa = malloc(sizeof(struct Nodo));
	/* riempi il campo dati */
	testa->n.num = x;
	testa->n.den = y;
	
	/* collega il nuovo nodo alla lista */
	testa->next = lista;
	
	return testa;
}

/* inserimento di un numero in testa alla lista */
struct Nodo* nuovoNumero(struct Nodo* lista) {
	int numeratore, denominatore;			// valori per il nuovo numero
	printf("Caro utente, quanto vale il numeratore del nuovo numero? ");
	scanf("%d", &numeratore);
	printf("Caro utente, quanto vale il denominatore del nuovo numero? ");
	scanf("%d", &denominatore);
	printf("\n");
	return inserisci(lista,numeratore,denominatore);
}

/*********************************************
 ************** CANCELLAZIONE *****************
 *********************************************/

/* cancellazione di un numero dal fondo della lista: un'implementazione diversa poteva usare
 * due puntatori, uno alla testa ed uno al fondo della lista  */
struct Nodo* cancellaNumero(struct Nodo *head) {
	// pre: lista non vuota
	struct Nodo* nodoCorrente;			// nodo da investigare
	struct Nodo* nodoPrec;				// nodo precedente 
	
	/* se la lista ha un solo elemento diventa vuota: dealloca il nodo e restituirai la lista vuota */
	if(head->next == NULL) {
		free(head);
		head = NULL;
	}
	else { 		// almeno due numeri
		/* per prima cosa arriva in fondo alla lista */
		nodoPrec = head;
		nodoCorrente = head->next;
		while(nodoCorrente->next!=NULL){
			nodoPrec = nodoCorrente;
			nodoCorrente = nodoCorrente->next;
		}
		/* OK sei in fondo: dealloca l'ultimo nodo ed il penultimo diventa ultimo */
		nodoPrec -> next = NULL;
		free(nodoCorrente);
	}
		
	/* stampa messaggio e termina */
	printf("Numero cancellato!\n\n");
	return head;
}

/*********************************************************
 ************************ ORDINAMENTO ********************
 *********************************************************/ 

/* restituisce 1 se il primo numero razionale � minore o uguale al secondo */
int minore(struct Numero n1, struct Numero n2) {
	return ((float)n1.num)/n1.den <= ((float)n2.num)/n2.den;
}
  
/* funzione che ordina gli elementi di una lista; implementa selection sort */
void ordina(struct Nodo *head) {
	struct Nodo *primo;				// primo nodo parte non ordinata
	struct Nodo *minimo;			// minimo corrente
	struct Nodo *nodo;				// nodo corrente
	struct Numero temp;			// variabile ausiliaria
	
	/* se la lista � vuota niente da fare */
	if(head != NULL) {
		/* il primo nodo non ordinato � il primo nodo della lista */
		primo = head;					
		/* prosegui fino a che la parte ordinata ha almeno due nodi */
		while(primo->next != NULL) {
			/* inizializza il minimo a primo */
			minimo = primo;
			/* guarda tutti i nodi a partire dal successivo a primo e prosegui fino a 
			 * che non li hai visti tutti */
			for(nodo = primo->next; nodo!=NULL; nodo = nodo -> next) 
				/* minore del minimo ? */
				if(minore(nodo->n, minimo->n)) 
					minimo = nodo;

			/* adesso scambia i campi dati del minimo e del primo elemento non ordinato */
			temp = primo->n;
			primo->n = minimo->n;
			minimo->n = temp;
			
			/* fai scorrere il primo elemento non ordinato */
			primo = primo->next;
		}
		printf("Lista ordinata!\n\n");
	}
	else 
		printf("Non c'%c molto da ordinare!\n\n", 138);
}


/******************************************
 ************ RIDUZIONE MINIMI *************
 ******************************************/

/* funzione per il calcolo del MCD di due numeri */
int mcd(int x, int y) {
	int res = x;
	while(x%res != 0 || y%res != 0)
		res--;
	return res;
}

/* funzione che riduce un numero ai minimi termini */
void riduci(struct Numero* puntaN) {
	int m = mcd(puntaN->num, puntaN->den);
	puntaN->num = puntaN->num /m;
	puntaN->den = puntaN->den /m;
}

/* funzione che riduce tutti i numeri di una lista ai minimi termini */
void riduciLista(struct Nodo* lista) {
	while(lista!= NULL) {
		riduci(&(lista->n));		// lo passo per riferimento cos� che le modifiche siano effettive
		lista = lista -> next;
	}
	printf("Lista ridotta!\n\n");
}

/**********************************************
 **************** GESTIONE FILE ****************
 **********************************************/

/* funzione per l'acquisizione di una lista su file */
struct Nodo* acquisizione() {
	FILE* fp = fopen("cerchi.dat", "rb");					// per la lettura di un file binario
	struct Nodo* head;											// testa della lista
	struct Nodo* current;										// nodo corrente
	struct Nodo* previous;										// nodo precedente
	
	struct Numero num;										// un numero razionale
	int letto;														// lettura OK o no
	
	/* leggi il primo nodo della lista */
	letto = fread(&num, sizeof(struct Numero), 1, fp);
	if(letto) {		// almeno un numero � presente nel file
		/* memorizza nell'heap il primo nodo della lista */ 
		head = malloc(sizeof(struct Nodo)) ;			
		head->n = num;
		
		/* devi tenere traccia dell'ultimo nodo letto, per collegarlo al successivo nella lista */
		previous = head;				
		/* adesso leggi tutti gli altri nodi */
		do {		
			/* leggi un nuovo nodo */
			letto = fread(&num, sizeof(struct Numero), 1, fp);
			if(letto) {		// lo hai effettivamente letto?
				/* memorizza nell'heap il nuovo nodo */ 
				current = malloc(sizeof(struct Nodo)) ;			
				current->n = num;
				
				/* collega il nuovo nodo al precedente */
				previous->next = current;
				
				/* il nuovo nodo diventa il precedente */
				previous = current;
			}
			else // il file � terminato, setta il campo next dell'ultimo nodo 
				previous -> next = NULL;
		}
		while(letto);
	}
	else // file vuoto
		head = NULL;
	return head;
}

/* funzione per il salvataggio di una lista su file */
void salvataggio(struct Nodo* lista) {
	FILE* fp = fopen("cerchi.dat", "wb");							// per la scrittura di un file binario
	while(lista!= NULL) {												// procedi fino a che hai nodi 
		fwrite(&(lista->n), sizeof(struct Numero), 1, fp);		// ci� che scrivi � un numero
		lista = lista->next;												// passa al prossimo nodo
	} 
}

/**********************************************
 ************ FUNZIONE PRINCIPALE ************
 **********************************************/

int main() {
	/* crea la lista */
	struct Nodo* lista = acquisizione();
	
	int risposta = -1;			// per interazione con utente
	
	while(risposta != 0) {
		/* richiedi un'operazione all'utente */
		printf("Che operazione vuoi svolgere?\n");
		printf("1 -> Inserisci un numero in testa alla lista\n");
		printf("2 -> Cancella l'ultimo numero della lista\n");
		printf("3 -> Visualizza la lista\n");
		printf("4 -> Ordina la lista\n");
		printf("5 -> Riduci i numeri della lista ai minimi termini\n");
		printf("0 -> Termina il programma\n");
		scanf("%d", &risposta);
		
		/* gestisci le operazioni dell'utente */
		if(risposta==1) {
			lista = nuovoNumero(lista);
		}
		else if(risposta==2) {
			if(lista!= NULL) 
				lista = cancellaNumero(lista);
			else
				printf("Non c'%c niente da cancellare!\n\n", 138);
		}
		else if(risposta==3) {
			stampa(lista);
		}
		else if(risposta==4) {
			ordina(lista);
		}
		else if(risposta==5) {
			riduciLista(lista);
		}
		else if(risposta==0) {
			printf("Adios!\n\n");
		}
		else printf("Selezione non valida!\n\n");
	}
	salvataggio(lista);
}