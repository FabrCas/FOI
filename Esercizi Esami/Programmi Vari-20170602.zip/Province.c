#include <stdio.h>
#include <string.h>

/* DEFINIZIONE STRUTTURE */
#define DIMENSIONE 100
#define LUNGHEZZANOME 30
 
/* struttura per rappresentare una provincia */
struct Provincia {
	char codice[2];
	char nome[LUNGHEZZANOME];
};

typedef struct Provincia provincia;

/* VARIABILI GLOBALI */
provincia elenco[DIMENSIONE];
int numeroProvince;

/******************************************************/
/***************** VISUALIZZAZIONE ********************/
/******************************************************/

/* funzione per visualizzare una provincia */
void stampaProvincia(provincia prov){
    printf("CODICE: ");
	for(int i=0; i<2; i++)
		putchar(prov.codice[i]);
	printf("\t NOME: %s\n", prov.nome);
}

/* funzione per visualizzare l'elenco di province */
void visualizza() {
	printf("**********************\n");
	printf("***** PROVINCE *******\n");
	printf("**********************\n\n");
	/* visualizza tutte le province nell'elenco */
	for(int i=0; i<numeroProvince; i++)
		stampaProvincia(elenco[i]);
	
	/* fai qualcosa di diverso se non ce ne sono */
	if(numeroProvince==0)
		printf("Non ci sono province\n\n");
	else
		printf("\n");
}

/******************************************************/
/********************** RICERCA ************************/
/******************************************************/

/* funzione per la ricerca di una citt� tramite il codice */
void ricerca() {
	int i;							// contatore
	char codice[2];			// codice da cercare

	/* leggi cosa cerca l'utente */
	printf("Che codice cerchi? ");
	for(i=0; i<2; i++)			// codice
		codice[i]=getchar();
	getchar();							// invio

	/* ricerca una provincia con quel codice */
	int trovato = 0;
	i=0;	
	while(!trovato && i<numeroProvince) {
		if(codice[0]==elenco[i].codice[0] && codice[1]==elenco[i].codice[1]) {
			// trovata!
			printf("La provincia con codice %c%c %c %s\n\n", codice[0], codice[1], 138, elenco[i].nome);
			trovato = 1;
		}
		else
			i++;
	}
	/* non c'�? */
	if(!trovato)
		printf("Mi dispiace, una provincia con questo codice non esiste");
}

/******************************************************/
/******************** INSERIMENTO *********************/
/******************************************************/

/* inserisce una nuova provincia */
void aggiungi() {
	/* ottieni i dati della provincia */
	printf("\nIntroduci il codice della provincia (due caratteri): ");
	for(int i=0; i<2; i++)		 // leggi due caratteri
		elenco[numeroProvince].codice[i] = getchar();
	getchar();		// leggi invio
	
	printf("\nIntroduci il nome della provincia: ");
	fgets(elenco[numeroProvince].nome, LUNGHEZZANOME, stdin);
	(elenco[numeroProvince].nome)[strlen(elenco[numeroProvince].nome)-1]='\0';
	
	numeroProvince++;
	printf("\nProvincia aggiunta!\n\n");
}



/******************************************************************/
/*************** FUNZIONI PER LA GESTIONE DEL FILE ******************/
/******************************************************************/

/* input */
void acquisici(){
    FILE *fpin;
    fpin = fopen("prov.dat","rb");
    if(fpin!=NULL) 
		numeroProvince =fread(elenco, sizeof(provincia),DIMENSIONE, fpin);
	fclose(fpin);
} 
 
/* output */
void salva(){
     FILE *fpout;
     fpout = fopen("prov.dat","wb"); 
     fwrite(elenco,sizeof(provincia),numeroProvince,fpout);
     fclose(fpout);
 }

/******************************************************************/
/********************* PROGRAMMA PRINCIPALE ***********************/
/******************************************************************/

 /* funzione principale di interazione con l'utente */
int main() {
	/* acquisizione dei dati da file */
	acquisici();
    
    visualizza();
    int numero = -1;
	
	/* ciclo di interazione con l'utente */
	while(numero!=0) {
		printf("Ciao utente! Puoi svolgere le seguenti operazioni:\n");
		printf("Introduci 1 -> Visualizza le province\n");
		printf("Introduci 2 -> Cerca una provincia per codice\n");
		printf("Introduci 3 -> Aggiungi una provincia\n");
		printf("Introduci 0 -> Termina il programma\n");
		scanf("%d%*c", &numero);
		
		/* visualizza le province */
		if(numero==1)
			visualizza();

		/* ricerca una provincia per codice */
		else if(numero==2)
			ricerca();
	
		/* visualizza le province */
		else if(numero==3)
			aggiungi();
	
		/* numero sbagliato? */
		else  if(numero!=0)
			printf("Questo numero non vuol dire niente. Riproviamo!\n");
	}

	salva();
    printf("\n ** lista salvata nel file \"prov.dat\" **\n");
    
}